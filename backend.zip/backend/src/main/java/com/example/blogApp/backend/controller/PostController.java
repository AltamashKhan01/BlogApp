package com.example.blogApp.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.blogApp.backend.model.Post;
import com.example.blogApp.backend.service.PostService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("api/posts")
public class PostController {

	@Autowired
	private PostService postService;

	@PostMapping
	public ResponseEntity<Object> createPost(@RequestBody Post post) {
		return postService.savePost(post);
	}

	@GetMapping("/all")
	public ResponseEntity<List<Post>> getAllPosts() {
		return postService.getAllPosts();
	}

	@GetMapping("{postId}")
	public ResponseEntity<Object> getPostById(@PathVariable Long postId) {
		return postService.getPostById(postId);
	}

	@PatchMapping("/like/{postId}")
	public ResponseEntity<Object> likePost(@PathVariable Long postId) {
		return postService.likePost(postId);
	}
	
	@PatchMapping("/dislike/{postId}")
	public ResponseEntity<Object> dislikePost(@PathVariable Long postId) {
		return postService.dislikePost(postId);
	}

	@GetMapping("/search/{name}")
	public ResponseEntity<Object> searchByName(@PathVariable String name) {
		return postService.searchByName(name);
	}
	
	@DeleteMapping("/delete/{postId}")
	public ResponseEntity<Object> deletePost(@PathVariable Long postId) {
		return postService.deletePost(postId);
	}
	
	@PutMapping("/update/{postId}")
	public ResponseEntity<Object> updatePost(@PathVariable Long postId, @RequestBody Post newPost) {
		return postService.updatePost(postId, newPost);
	}

}
