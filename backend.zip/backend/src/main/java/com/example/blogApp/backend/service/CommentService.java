package com.example.blogApp.backend.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.blogApp.backend.model.Comment;
import com.example.blogApp.backend.model.Post;
import com.example.blogApp.backend.repository.CommentRepo;
import com.example.blogApp.backend.repository.PostRepo;

@Service
public class CommentService {

	@Autowired
	private CommentRepo commentRepo;

	@Autowired
	private PostRepo postRepo;

	public ResponseEntity<Object> createComent(Long postId, String postedBy, String content) {
		Optional<Post> optionalPost = postRepo.findById(postId);

		if (optionalPost.isPresent()) {
			Comment comment = new Comment();

			comment.setPost(optionalPost.get());
			comment.setPostedBy(postedBy);
			comment.setContent(content);
			comment.setCreatedAt(new Date());
			commentRepo.save(comment);
			return ResponseEntity.status(HttpStatus.CREATED).body(comment);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Post not found");
		}
	}

	public ResponseEntity<Object> getCommentsByPostId(Long postId) {
		Optional<Post> optionalPost = postRepo.findById(postId);

		if (optionalPost.isPresent()) {
			List<Comment> list = commentRepo.findByPostId(postId);
			return ResponseEntity.status(HttpStatus.CREATED).body(list);

		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Post not found");
		}
	}

	public ResponseEntity<Object> deleteComment(Long commentId) {
		// TODO Auto-generated method stub

		Optional<Comment> optionalComment = commentRepo.findById(commentId);
		if (optionalComment.isPresent()) {
			commentRepo.delete(optionalComment.get());
			return ResponseEntity.status(HttpStatus.OK).body("Comment deleted successfully");

		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Comment not found");
		}
	}

	public ResponseEntity<Object> deleteAllCommentsByPostId(Long postId) {
		// TODO Auto-generated method stub
		List<Comment> commentsToDelete = commentRepo.findByPostId(postId);

		long count = commentsToDelete.size();
		if (count > 0) {
			commentRepo.deleteAll(commentsToDelete);

			return ResponseEntity.status(HttpStatus.OK)
					.body("All " + count + " comments for this post deleted successfully!");
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Comment not found");
		}

	}
}
