package com.example.blogApp.backend.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.blogApp.backend.model.Post;
import com.example.blogApp.backend.repository.PostRepo;

@Service
public class PostService {

	@Autowired
	private PostRepo postRepo;

	public ResponseEntity<Object> savePost(Post post) {

		try {
			post.setLikeCount(0);
			post.setViewCount(0);
			post.setDate(new Date());

			Post createdPost = postRepo.save(post);
			return ResponseEntity.status(HttpStatus.CREATED).body(createdPost);

		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}

	}

	public ResponseEntity<List<Post>> getAllPosts() {
		try {
			List<Post> list = postRepo.findAll();

			if (list.isEmpty())
				return ResponseEntity.status(HttpStatus.OK).body(new ArrayList<>());

			return ResponseEntity.status(HttpStatus.OK).body(list);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}

	}

	public ResponseEntity<Object> getPostById(Long postId) {
		// TODO Auto-generated method stub
		Optional<Post> optionalPost = postRepo.findById(postId);

		if (optionalPost.isPresent()) {
			Post post = optionalPost.get();
			post.setViewCount(post.getViewCount() + 1);
			postRepo.save(post);
			return ResponseEntity.status(HttpStatus.OK).body(post);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Post not found");
		}
	}

	public ResponseEntity<Object> likePost(Long postId) {
		Optional<Post> optionalPost = postRepo.findById(postId);
		if (optionalPost.isPresent()) {

			Post post = optionalPost.get();
			post.setLikeCount(post.getLikeCount() + 1);
			postRepo.save(post);
			return ResponseEntity.status(HttpStatus.OK).body(post);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Post not found");
		}
	}
	
	public ResponseEntity<Object> dislikePost(Long postId) {
		Optional<Post> optionalPost = postRepo.findById(postId);
		if (optionalPost.isPresent()) {

			Post post = optionalPost.get();
			if (post.getLikeCount() > 0) post.setLikeCount(post.getLikeCount() - 1);
			postRepo.save(post);
			return ResponseEntity.status(HttpStatus.OK).body(post);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Post not found");
		}
	}

	public ResponseEntity<Object> searchByName(String name) {
		List<Post> list = postRepo.findAllByNameContaining(name);

		if (list.size() > 0) {
			return ResponseEntity.status(HttpStatus.OK).body(list);
		} else {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	public ResponseEntity<Object> deletePost(Long postId) {
		// TODO Auto-generated method stub
		Optional<Post> optionalPost = postRepo.findById(postId);
		if (optionalPost.isPresent()) {

			Post post = optionalPost.get();
			postRepo.delete(post);
			return ResponseEntity.status(HttpStatus.OK).body("Post deleted successfully");
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Post not found");
		}
	}

	public ResponseEntity<Object> updatePost(Long postId, @RequestBody Post newPost) {
		// TODO Auto-generated method stub
		Optional<Post> optionalPost = postRepo.findById(postId);
		if (optionalPost.isPresent()) {

			Post postFromDB = optionalPost.get();
			
			postFromDB.setContent(newPost.getContent());
			postFromDB.setImgUrl(newPost.getImgUrl());
			postFromDB.setName(newPost.getName());
			postFromDB.setTags(newPost.getTags());
			postFromDB.setLikeCount(0);
			postFromDB.setViewCount(0);
			
			postRepo.save(postFromDB);
			return ResponseEntity.status(HttpStatus.OK).body(postFromDB);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Post not found");
		}

	}
	
	

}
