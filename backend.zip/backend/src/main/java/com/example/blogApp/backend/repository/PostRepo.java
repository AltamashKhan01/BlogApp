package com.example.blogApp.backend.repository;

import java.util.Date;
import java.util.List;
import org.springframework.data.domain.Pageable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.blogApp.backend.model.Post;

@Repository
public interface PostRepo extends JpaRepository<Post, Long> {

	List<Post> findAllByNameContaining(String name);

	@Query("SELECT SUM(p.likeCount) FROM Post p")
	Long sumLikeCount();

	@Query("SELECT SUM(p.viewCount) FROM Post p")
	Long sumViewCount();

	// Average methods
	@Query("SELECT AVG(p.likeCount) FROM Post p")
	Double avgLikeCount();

	@Query("SELECT AVG(p.viewCount) FROM Post p")
	Double avgViewCount();

	// Top posts
	List<Post> findTopByOrderByLikeCountDesc(Pageable pageable);

	List<Post> findTopByOrderByViewCountDesc(Pageable pageable);

	List<Post> findTopByOrderByDateDesc(Pageable pageable);

	List<Post> findTopByOrderByDateAsc(Pageable pageable);

	// Posts with no engagement
	@Query("SELECT COUNT(p) FROM Post p WHERE p.likeCount = 0")
	Long countPostsWithNoLikes();

	// Time-based queries
	List<Post> findByDateAfter(Date date);

	// User-related queries
	@Query("SELECT p.postedBy, COUNT(p) FROM Post p GROUP BY p.postedBy ORDER BY COUNT(p) DESC")
	List<Object[]> findMostActiveAuthors(Pageable pageable);

	@Query("SELECT COUNT(DISTINCT p.postedBy) FROM Post p")
	Long countDistinctPostedBy();

	// Content analysis
	@Query("SELECT AVG(LENGTH(p.content)) FROM Post p")
	Double avgContentLength();

	// Tag analysis (assuming tags are stored as a comma-separated string)
	@Query("SELECT p.tags FROM Post p")
	List<String> findAllTags();

}
