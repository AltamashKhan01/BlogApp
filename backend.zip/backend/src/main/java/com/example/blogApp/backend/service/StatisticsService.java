package com.example.blogApp.backend.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.blogApp.backend.model.Post;
import com.example.blogApp.backend.repository.CommentRepo;
import com.example.blogApp.backend.repository.PostRepo;

@Service
public class StatisticsService {

	private final PostRepo postRepository;
	private final CommentRepo commentRepository;
	private static final Logger logger = LoggerFactory.getLogger(StatisticsService.class);

	@Autowired
	public StatisticsService(PostRepo postRepository, CommentRepo commentRepository) {
		this.postRepository = postRepository;
		this.commentRepository = commentRepository;
	}

	public ResponseEntity<Map<String, Object>> getStatistics() {
		try {
			Map<String, Object> stats = getComprehensiveStatistics();
			return ResponseEntity.ok(stats);
		} catch (Exception e) {
			// Log the error
			logger.error("Error generating statistics", e);
			// Return an error response
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(Map.of("error", "Failed to generate statistics", "message", e.getMessage()));
		}
	}

	public Map<String, Object> getComprehensiveStatistics() {
		Map<String, Object> stats = new HashMap<>();

		// Basic counts
		long totalPosts = postRepository.count();
		long totalComments = commentRepository.count();
		Long totalLikes = postRepository.sumLikeCount();
		Long totalViews = postRepository.sumViewCount();

		// Handle null values
		totalLikes = totalLikes != null ? totalLikes : 0L;
		totalViews = totalViews != null ? totalViews : 0L;

		// Add basic stats to map
		stats.put("totalPosts", totalPosts);
		stats.put("totalComments", totalComments);
		stats.put("totalLikes", totalLikes);
		stats.put("totalViews", totalViews);

		// Calculate averages
		Double avgLikesPerPost = postRepository.avgLikeCount();
		Double avgViewsPerPost = postRepository.avgViewCount();
		Double avgCommentsPerPost = totalPosts > 0 ? (double) totalComments / totalPosts : 0;

		stats.put("avgLikesPerPost", avgLikesPerPost != null ? avgLikesPerPost : 0);
		stats.put("avgViewsPerPost", avgViewsPerPost != null ? avgViewsPerPost : 0);
		stats.put("avgCommentsPerPost", avgCommentsPerPost);

		// Top posts
		List<Post> mostLikedPosts = postRepository.findTopByOrderByLikeCountDesc(PageRequest.of(0, 1));
		List<Post> mostViewedPosts = postRepository.findTopByOrderByViewCountDesc(PageRequest.of(0, 1));
		List<Post> newestPosts = postRepository.findTopByOrderByDateDesc(PageRequest.of(0, 1));
		List<Post> oldestPosts = postRepository.findTopByOrderByDateAsc(PageRequest.of(0, 1));

		if (!mostLikedPosts.isEmpty())
			stats.put("mostLikedPost", mostLikedPosts.get(0));
		if (!mostViewedPosts.isEmpty())
			stats.put("mostViewedPost", mostViewedPosts.get(0));
		if (!newestPosts.isEmpty())
			stats.put("newestPost", newestPosts.get(0));
		if (!oldestPosts.isEmpty())
			stats.put("oldestPost", oldestPosts.get(0));

		// Most commented post
		List<Object[]> mostCommentedPostIds = commentRepository.findMostCommentedPostIds(PageRequest.of(0, 1));
		if (!mostCommentedPostIds.isEmpty()) {
			Long postId = (Long) mostCommentedPostIds.get(0)[0];
			Optional<Post> mostCommentedPost = postRepository.findById(postId);
			mostCommentedPost.ifPresent(post -> stats.put("mostCommentedPost", post));
			stats.put("mostCommentedPostCount", mostCommentedPostIds.get(0)[1]);
		}

		// Posts with no engagement
		stats.put("postsWithNoLikes", postRepository.countPostsWithNoLikes());
		stats.put("postsWithNoComments", commentRepository.countPostsWithNoComments());

		// User statistics
		stats.put("uniqueAuthors", postRepository.countDistinctPostedBy());
		stats.put("uniqueCommenters", commentRepository.countDistinctPostedBy());

		List<Object[]> mostActiveAuthors = postRepository.findMostActiveAuthors(PageRequest.of(0, 1));
		List<Object[]> mostActiveCommenters = commentRepository.findMostActiveCommenters(PageRequest.of(0, 1));

		if (!mostActiveAuthors.isEmpty()) {
			stats.put("mostActiveAuthor", mostActiveAuthors.get(0)[0]);
			stats.put("mostActiveAuthorPostCount", mostActiveAuthors.get(0)[1]);
		}

		if (!mostActiveCommenters.isEmpty()) {
			stats.put("mostActiveCommenter", mostActiveCommenters.get(0)[0]);
			stats.put("mostActiveCommenterCount", mostActiveCommenters.get(0)[1]);
		}


		// Content analysis
		Double avgPostLength = postRepository.avgContentLength();
		Double avgCommentLength = commentRepository.avgContentLength();

		stats.put("avgPostLength", avgPostLength != null ? avgPostLength : 0);
		stats.put("avgCommentLength", avgCommentLength != null ? avgCommentLength : 0);

		// Tag analysis
		List<String> allTags = postRepository.findAllTags();
		Map<String, Integer> tagCounts = new HashMap<>();

		for (String tagString : allTags) {
			if (tagString != null && !tagString.isEmpty()) {
				String[] tags = tagString.split(",");
				for (String tag : tags) {
					String trimmedTag = tag.trim();
					tagCounts.put(trimmedTag, tagCounts.getOrDefault(trimmedTag, 0) + 1);
				}
			}
		}

		stats.put("totalUniqueTags", tagCounts.size());

		if (!tagCounts.isEmpty()) {
			Map.Entry<String, Integer> mostPopularTag = tagCounts.entrySet().stream().max(Map.Entry.comparingByValue())
					.orElse(null);

			if (mostPopularTag != null) {
				stats.put("mostPopularTag", mostPopularTag.getKey());
				stats.put("mostPopularTagCount", mostPopularTag.getValue());
			}
		}

		return stats;
	}

}
