package com.example.blogApp.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.blogApp.backend.service.CommentService;

@RestController
@RequestMapping("/api/comments")
@CrossOrigin(origins = "*")
public class CommentController {

	@Autowired
	private CommentService commentService;

	@PostMapping("create")
	public ResponseEntity<Object> createComment(@RequestParam Long postId, @RequestParam String postedBy,
			@RequestBody String content) {
		return commentService.createComent(postId, postedBy, content);
	}

	@GetMapping("{postId}")
	public ResponseEntity<Object> getCommentsByPostId(@PathVariable Long postId) {
		return commentService.getCommentsByPostId(postId);
	}
	
	@DeleteMapping("delete/{commentId}")
	public ResponseEntity<Object> deleteComment(@PathVariable Long commentId) {
		return commentService.deleteComment(commentId);
	}
	
	@DeleteMapping("delete/all/{postId}")
	public ResponseEntity<Object> deleteAllCommentsByPostId(@PathVariable Long postId) {
		return commentService.deleteAllCommentsByPostId(postId);
	}
}
