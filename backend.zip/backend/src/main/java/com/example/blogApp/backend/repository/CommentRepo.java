package com.example.blogApp.backend.repository;

import java.util.Date;
import org.springframework.data.domain.Pageable;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.blogApp.backend.model.Comment;

@Repository
public interface CommentRepo extends JpaRepository<Comment, Long> {
	
	List<Comment> findByPostId(Long postId);
	
	// Count by post
//    @Query("SELECT c.postId, COUNT(c) FROM Comment c GROUP BY c.postId ORDER BY COUNT(c) DESC")
//    List<Object[]> findMostCommentedPostIds(Pageable pageable);
    
    @Query("SELECT c.post.id, COUNT(c) FROM Comment c GROUP BY c.post.id ORDER BY COUNT(c) DESC")
    List<Object[]> findMostCommentedPostIds(Pageable pageable);

    
    Long countByPostId(Long postId);
    
    // Posts with no comments
//    @Query("SELECT COUNT(p) FROM Post p WHERE NOT EXISTS (SELECT c FROM Comment c WHERE c.postId = p.id)")
//    Long countPostsWithNoComments();
    
    @Query("SELECT COUNT(p) FROM Post p WHERE NOT EXISTS (SELECT c FROM Comment c WHERE c.post.id = p.id)")
    Long countPostsWithNoComments();

    
    // Time-based queries
    List<Comment> findByCreatedAtAfter(Date date);
    
    // User-related queries
    @Query("SELECT c.postedBy, COUNT(c) FROM Comment c GROUP BY c.postedBy ORDER BY COUNT(c) DESC")
    List<Object[]> findMostActiveCommenters(Pageable pageable);
    
    @Query("SELECT COUNT(DISTINCT c.postedBy) FROM Comment c")
    Long countDistinctPostedBy();
    
    // Content analysis
    @Query("SELECT AVG(LENGTH(c.content)) FROM Comment c")
    Double avgContentLength();
	

}
