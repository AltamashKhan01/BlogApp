import {
  InjectionToken
} from "./chunk-56PPHEMJ.js";

// node_modules/@angular/material/fesm2022/input-value-accessor-8a79a24e.mjs
var MAT_INPUT_VALUE_ACCESSOR = new InjectionToken("MAT_INPUT_VALUE_ACCESSOR");

export {
  MAT_INPUT_VALUE_ACCESSOR
};
//# sourceMappingURL=chunk-C4DHVO5O.js.map
