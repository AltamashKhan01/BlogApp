import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterModule, RouterOutlet } from '@angular/router';
import { AngularMaterialModule } from './AngularMaterialModule';
import { CommonModule } from '@angular/common';
import { ThemeService } from './service/theme.service';
import { PostService } from './service/post.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, ReactiveFormsModule, FormsModule, HttpClientModule, AngularMaterialModule, RouterModule, CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
  providers: [ThemeService, PostService]
})
export class AppComponent {
  title = 'blogWeb';
  isDarkTheme = false;

  constructor(private router: Router, private themeService: ThemeService, private snackBar: MatSnackBar, private postService: PostService) {
    this.themeService.isDarkTheme$.subscribe(isDark => {
      this.isDarkTheme = isDark;
      console.log('Theme updated in component:', isDark);
    });
  }

  toggleTheme() {
    // Implement theme toggling if you want this feature

    this.themeService.toggleTheme();

    console.log('Theme toggle clicked');
  }


  // Method to navigate to a random post
  showRandomPost(): void {
    this.snackBar.open('Finding a random post...', '', {
      duration: 700
    });

    this.postService.getAllPosts().subscribe({
      next: (posts) => {
        if (posts && posts.length > 0) {
          // Get a random index
          const randomIndex = Math.floor(Math.random() * posts.length);
          // Get the random post ID
          const randomPostId = posts[randomIndex].id;
          // Navigate to the view-post page with the random post ID
          this.router.navigate(['/view', randomPostId]);
        } else {
          this.snackBar.open('No posts found. Create some posts first!', 'OK', {
            duration: 3000
          });
          this.router.navigate(['/create-post']);
        }
      },
      error: (error) => {
        console.error('Error fetching posts:', error);
        this.snackBar.open('Error loading random post. Please try again.', 'OK', {
          duration: 3000
        });
      }
    });
  }
}




