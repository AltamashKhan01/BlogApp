import { Injectable } from '@angular/core';
import { Post } from '../model/post.model';
import { HttpClient } from '@angular/common/http';
import { PostService } from './post.service';

@Injectable({
  providedIn: 'root'
})
export class BookmarkService {
  private cookieName = 'bookmarkedPosts';

  constructor(private http: HttpClient,
    private postservice: PostService
  ) { }

  bookmarkPost(postId: number): boolean {
    try {
      console.log('BookmarkService: Toggle bookmark for post ID:', postId);

      // Get current bookmarks
      let bookmarkedPosts = this.getBookmarkedPostIds();

      // Check if the post is currently bookmarked
      const isCurrentlyBookmarked = bookmarkedPosts.includes(postId);
      console.log('BookmarkService: Post is currently bookmarked:', isCurrentlyBookmarked);

      if (isCurrentlyBookmarked) {
        // Remove ALL instances of this postId from the array
        bookmarkedPosts = bookmarkedPosts.filter(id => id !== postId);
        console.log('BookmarkService: All instances of post removed from bookmarks');
      } else {
        // Add the post to bookmarks (only if it doesn't exist)
        if (!bookmarkedPosts.includes(postId)) {
          bookmarkedPosts.push(postId);
          console.log('BookmarkService: Post added to bookmarks');
        }
      }

      // Save the updated bookmarks
      this.setCookie(this.cookieName, JSON.stringify(bookmarkedPosts), 100);

      // Return the new bookmark state
      return !isCurrentlyBookmarked;
    } catch (error) {
      console.error('Error toggling bookmark for post:', error);
      return false;
    }
  }



  getBookmarkedPostIds(): number[] {
    const cookieValue = this.getCookie(this.cookieName);
    if (!cookieValue) return [];

    try {
      const bookmarks: number[] = JSON.parse(cookieValue);
      // Use Set to remove duplicates
      const uniqueBookmarks: number[] = [...new Set(bookmarks)];

      // If we found and removed duplicates, update the cookie
      if (uniqueBookmarks.length !== bookmarks.length) {
        console.log('Removed duplicate bookmarks:', bookmarks.length - uniqueBookmarks.length);
        this.setCookie(this.cookieName, JSON.stringify(uniqueBookmarks), 100);
      }

      return uniqueBookmarks;
    } catch (error) {
      console.error('Error parsing bookmarked posts from cookie:', error);
      // Clear the corrupted cookie
      this.setCookie(this.cookieName, '[]', 100);
      return [];
    }
  }


  getBookmarkedPosts(): Promise<Post[]> {
    const postIds = this.getBookmarkedPostIds();

    if (postIds.length === 0) {
      // return empty array if no bookmarks
      return Promise.resolve([]);
    }

    const promises = postIds.map(
      (postId) => this.postservice.getPostById(postId).toPromise()
    );
    return Promise.all(promises);
  }

  private setCookie(name: string, value: string, days: number): void {
    try {
      let expires = '';
      if (days) {
        const date = new Date();
        date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
        expires = '; expires=' + date.toUTCString();
      }

      document.cookie = name + '=' + encodeURIComponent(value) + expires + '; path=/';
      console.log('Cookie set successfully:', name);
    } catch (error) {
      console.error('Error setting cookie:', error);
    }
  }


  private getCookie(name: string): string | null {
    const nameEQ = name + '=';
    const ca = document.cookie.split(";");
    for (let i = 0; i < ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) === ' ') c = c.substring(1, c.length);

      if (c.indexOf(nameEQ) === 0) {
        const encodedValue = c.substring(nameEQ.length, c.length);
        // Decode the URL-encoded value before returning it
        return decodeURIComponent(encodedValue);
      }
    }
    return null;
  }

  private removeDuplicates(array: number[]): number[] {
    return [...new Set(array)];
  }

  isPostBookmarked(postId: number): boolean {
    const bookmarkedPosts = this.getBookmarkedPostIds();
    return bookmarkedPosts.includes(postId);
  }

  resetBookmarks(): void {
    // Clear all bookmarks by setting an empty array
    this.setCookie(this.cookieName, '[]', 100);
    console.log('All bookmarks have been reset');
  }

}
