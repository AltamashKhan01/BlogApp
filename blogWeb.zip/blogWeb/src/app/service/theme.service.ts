import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {
  private isDarkTheme = new BehaviorSubject<boolean>(false);
  
  // Observable that components can subscribe to
  public isDarkTheme$ = this.isDarkTheme.asObservable();

  constructor() {
    // Check if user has a saved preference
    const savedTheme = localStorage.getItem('pixelprose-theme');
    if (savedTheme) {
      this.isDarkTheme.next(savedTheme === 'dark');
      this.applyTheme(savedTheme === 'dark');
    } else {
      // Check if user prefers dark mode at OS level
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      this.isDarkTheme.next(prefersDark);
      this.applyTheme(prefersDark);
    }
  }

  toggleTheme(): void {
    const newThemeValue = !this.isDarkTheme.value;
    this.isDarkTheme.next(newThemeValue);
    
    // Save preference to localStorage
    localStorage.setItem('pixelprose-theme', newThemeValue ? 'dark' : 'light');
    
    // Apply the theme
    this.applyTheme(newThemeValue);
    
    console.log('Theme toggled to:', newThemeValue ? 'dark' : 'light'); // Debug log
  }

  private applyTheme(isDark: boolean): void {
    // Apply theme to document body
    if (isDark) {
      document.body.classList.add('dark-theme');
      document.body.classList.remove('light-theme');
    } else {
      document.body.classList.add('light-theme');
      document.body.classList.remove('dark-theme');
    }
  }
}
