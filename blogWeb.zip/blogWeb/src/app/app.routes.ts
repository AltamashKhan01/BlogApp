import { Routes } from '@angular/router';
import { CreatePostComponent } from './pages/create-post/create-post.component';
import { ViewAllPostsComponent } from './pages/view-all-posts/view-all-posts.component';
import { ViewPostComponent } from './pages/view-post/view-post.component';
import { SearchByNameComponent } from './pages/search-by-name/search-by-name.component';
import { UpdatePostComponent } from './pages/update-post/update-post.component';
import { BookmarksComponent } from './pages/bookmarks/bookmarks.component';
import { HomeComponent } from './pages/home/home.component';
import { StatsComponent } from './pages/stats/stats.component';

export const routes: Routes = [
    {
        path: 'create-post',
        component: CreatePostComponent
    },
    {
        path: 'view-all',
        component: ViewAllPostsComponent
    },
    {
        path: 'view/:id',
        component: ViewPostComponent
    },
    {
        path: 'search-by-name',
        component: SearchByNameComponent
    },
    {
        path: 'update-post/:id',
        component: UpdatePostComponent
    },
    {
        path: 'bookmarks',
        component: BookmarksComponent
    },
    {
        path: 'home',
        component: HomeComponent
    },
    {
        path: 'stats',
        component: StatsComponent
    },
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    }
];
