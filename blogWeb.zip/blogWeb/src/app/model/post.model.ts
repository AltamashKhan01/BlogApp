export interface Post {
    id: number,
    content: string,
    postedBy: string,
    imgUrl: string,
    tags: any,
    name: string,
    likeCount: number,
    viewCount: number,
    date: Date
}