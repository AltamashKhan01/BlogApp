import { Post } from './post.model';

export interface Stats {
    // Overview stats
    totalPosts: number;
    totalComments: number;
    totalViews: number;
    totalLikes: number;

    // Content stats
    avgPostLength: number;
    avgLikesPerPost: number;
    avgCommentsPerPost: number;
    avgViewsPerPost: number;
    avgCommentLength: number;

    // Tag stats
    mostPopularTag: string;
    mostPopularTagCount: number;
    totalUniqueTags: number;

    // Community stats
    mostActiveAuthor: string;
    mostActiveAuthorPostCount: number;
    mostActiveCommenter: string;
    mostActiveCommenterCount: number;
    uniqueAuthors: number;
    uniqueCommenters: number;

    // Additional metrics
    postsWithNoLikes: number;
    postsWithNoComments: number;

    // Featured posts
    mostViewedPost: Post;
    mostCommentedPost: Post;
    mostCommentedPostCount: number;
    mostLikedPost: Post;

    // Timeline posts
    oldestPost: Post;
    newestPost: Post;
}