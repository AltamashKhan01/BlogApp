import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { AngularMaterialModule } from '../../AngularMaterialModule';
import { PostService } from '../../service/post.service';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { CommentService } from '../../service/comment.service';
import { BookmarkService } from '../../service/bookmark.service';

@Component({
  selector: 'app-view-post',
  imports: [AngularMaterialModule, CommonModule, HttpClientModule, RouterModule],
  templateUrl: './view-post.component.html',
  styleUrl: './view-post.component.scss',
  providers: [PostService, CommentService, BookmarkService]
})
export class ViewPostComponent {

  postId: any;
  postData: any;
  commentList: any;
  commentForm!: FormGroup;
  isBookmarked: boolean = false;

  constructor(
    private postService: PostService,
    private activatedRoute: ActivatedRoute,
    private matSnackBar: MatSnackBar,
    private bookmarkService: BookmarkService,
    private router: Router,
    private fb: FormBuilder,
    private commentService: CommentService
  ) { }

  ngOnInit() {
    this.postId = this.activatedRoute.snapshot.params['id'];
    console.log(this.postId);
    this.getPostById();

    this.commentForm = this.fb.group({
      postedBy: [null, Validators.required],
      content: [null, Validators.required]
    })
  }

  publishComment() {
    const postedBy = this.commentForm.get('postedBy')?.value;
    const content = this.commentForm.get('content')?.value;

    this.commentService.createComment(this.postId, postedBy, content).subscribe(res => {
      this.matSnackBar.open("Comment Published Successfully!", "OK", { duration: 7000 });
      window.location.reload();
      this.getCommentsByPost();
    }, error => {
      console.log(error);
      this.matSnackBar.open("Something Went Wrong!!!", "OK", { duration: 4000 });
    })
  }

  getPostById() {
    this.postService.getPostById(this.postId).subscribe(res => {
      this.postData = res;
      console.log(res);
      this.getCommentsByPost();
      this.checkBookmarkStatus();

    }, error => {
      console.log(error);
      this.matSnackBar.open("Something Went Wrong!!!", "OK", { duration: 4000 });
    })
  }

  clearCommentForm(): void {
    this.commentForm.reset();
  }

  isLiked = false;
  likePost() {
    if (!this.isLiked) {
      this.postService.likePostById(this.postId).subscribe(res => {
        this.isLiked = !this.isLiked;
        this.matSnackBar.open("Post Liked Successfuly!", "OK", { duration: 3000 });
        this.getPostById();
      }
        , error => {
          console.log(error);
          this.matSnackBar.open("Something Went Wrong!!!", "OK", { duration: 4000 });
        })
    } else {
      this.postService.dislikePostById(this.postId).subscribe(res => {
        this.isLiked = !this.isLiked;
        // this.matSnackBar.open("Post Liked Successfuly!", "OK");
        this.getPostById();
      }
        , error => {
          console.log(error);
          this.matSnackBar.open("Something Went Wrong!!!", "OK", { duration: 4000 });
        })
    }
  }

  getCommentsByPost() {
    this.commentService.getAllCommentsByPost(this.postId).subscribe(res => {
      this.commentList = res;
    }, error => {
      console.log(error);
      this.matSnackBar.open("Something Went Wrong!!!", "OK", { duration: 4000 });
    }
    )
  }

  deletePost() {
    // first delete all the comments for that post
    this.deleteAllCommentsByPostId(this.postId);

    // now delete that post
    this.postService.deletePostById(this.postId).subscribe(res => {
      this.matSnackBar.open("Post Deleted Successfuly!", "OK", { duration: 4000 });
      this.router.navigate(['/view-all']);
    }, error => {
      console.log(error);
      this.matSnackBar.open("Something Went Wrong!!!", "OK", { duration: 4000 });
      window.location.reload();
    })
  }

  navigateToUpdatePost(postId: number) {
    this.router.navigate(['/update-post/', this.postId]);
  }

  deleteComment(commentId: number) {
    this.commentService.deleteComment(commentId).subscribe(res => {
      this.matSnackBar.open("Comment Deleted Successfuly!", "OK", { duration: 3000 });
      window.location.reload();
      this.getCommentsByPost();
    }, error => {
      console.log(error);
      this.matSnackBar.open("Something Went Wrong!!!", "OK", { duration: 3000 });
    })
  }

  deleteAllCommentsByPostId(postId: number) {
    this.commentService.deleteAllCommentsByPostId(postId).subscribe(res => {
      // this.matSnackBar.open("Comment Deleted Successfuly!", "OK");
      // window.location.reload();
      // this.getCommentsByPost();
    }, error => {
      console.log(error);
      this.matSnackBar.open("Something Went Wrong!!!", "OK", { duration: 3000 });
    })
  }

  bookmarkPost() {
    console.log("bookmarkPost clicked");

    this.bookmarkService.bookmarkPost(this.postId);
  }


  checkBookmarkStatus(): void {
    if (this.postData && this.postData.id) {
      const bookmarkedPosts = this.bookmarkService.getBookmarkedPostIds();
      this.isBookmarked = bookmarkedPosts.includes(this.postData.id);
      console.log('Bookmark status checked:', this.isBookmarked);
    }
  }


  toggleBookmark(event: Event) {
    // Prevent event bubbling
    event.stopPropagation();
    event.preventDefault();

    if (!this.postData || !this.postData.id) {
      console.error('Cannot toggle bookmark: Post data is not available');
      return;
    }

    console.log('Toggling bookmark for post ID:', this.postData.id);
    console.log('Current bookmark status before toggle:', this.isBookmarked);

    // The bookmarkPost method now returns the new bookmark state
    const newBookmarkState = this.bookmarkService.bookmarkPost(this.postData.id);

    // Update the UI state
    this.isBookmarked = newBookmarkState;

    console.log('New bookmark status after toggle:', this.isBookmarked);
  }


}
