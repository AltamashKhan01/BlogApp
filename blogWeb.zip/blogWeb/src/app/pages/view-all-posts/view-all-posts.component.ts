import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { AngularMaterialModule } from '../../AngularMaterialModule';
import { PostService } from '../../service/post.service';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { Post } from '../../model/post.model';


@Component({
  selector: 'app-view-all-posts',
  imports: [AngularMaterialModule, CommonModule, HttpClientModule],
  templateUrl: './view-all-posts.component.html',
  styleUrl: './view-all-posts.component.scss',
  providers: [PostService]
})

export class ViewAllPostsComponent {

  allPosts: any;

  constructor(
    private postService: PostService,
    private snackBar: MatSnackBar
  ) {

  }

  ngOnInit() {
    this.getAllPosts();
  }

  getAllPosts() {
    this.postService.getAllPosts().subscribe(
      (posts) => {
        // Sort posts by date (newest first)
        this.allPosts = posts.sort((a: Post, b: Post) => {
          // Convert dates to timestamps for comparison
          const dateA = new Date(a.date).getTime();
          const dateB = new Date(b.date).getTime();
          return dateB - dateA; // Descending order (newest first)
        });
      },
      (error) => {
        console.error('Error fetching posts:', error);
        // Handle error appropriately
      }
    );

  }
}
