import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { AngularMaterialModule } from '../../AngularMaterialModule';
import { PostService } from '../../service/post.service';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-create-post',
  imports: [AngularMaterialModule, CommonModule, HttpClientModule],
  templateUrl: './create-post.component.html',
  styleUrl: './create-post.component.scss',
  providers: [PostService]

})
export class CreatePostComponent {

  postForm !: FormGroup;
  tags: string[] = [];

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private snackBar: MatSnackBar,
    private postService: PostService
  ) {

  }

  ngOnInit() {
    this.postForm = this.fb.group({
      name: [null, Validators.required],
      content: [null, [Validators.required, Validators.maxLength(50000)]],
      imgUrl: [null, Validators.required],
      postedBy: [null, Validators.required]
    })
  }

  createPost() {
    const data = this.postForm.value;
    data.tags = this.tags;

    this.postService.createNewPost(data).subscribe(
      res => {
        this.snackBar.open("Post Created Successfully!", "OK", { duration: 7000 });
        this.router.navigateByUrl("/view-all");

      }, error => {
        console.log("error in post compon createPost method", error);
        this.snackBar.open("Something Went Wrong!!!", "OK", { duration: 4000 });
      }
    )

  }

  addTag(event: any) {
    const tag = (event.value || '').trim();
    if (tag) {
      this.tags.push(tag);
    }
    event.chipInput!.clear();
  }

  removeTag(tag: any) {
    const index = this.tags.indexOf(tag);

    if (index >= 0) this.tags.splice(index, 1);
  }

}
