import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { AngularMaterialModule } from '../../AngularMaterialModule';
import { PostService } from '../../service/post.service';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { CommentService } from '../../service/comment.service';
import { BookmarkService } from '../../service/bookmark.service';
import { Stats } from '../../model/stats.model';
import { Post } from '../../model/post.model';

@Component({
  selector: 'app-stats',
  imports: [AngularMaterialModule, CommonModule, HttpClientModule, RouterModule],
  templateUrl: './stats.component.html',
  styleUrl: './stats.component.scss'
})
export class StatsComponent {

  // Overview stats
  totalPosts: number = 0;
  totalComments: number = 0;
  totalViews: number = 0;
  totalLikes: number = 0;
  
  // Content stats
  avgPostLength: number = 0;
  avgLikesPerPost: number = 0;
  avgCommentsPerPost: number = 0;
  avgViewsPerPost: number = 0;
  avgCommentLength: number = 0;
  
  // Tag stats
  mostPopularTag: string = '';
  mostPopularTagCount: number = 0;
  totalUniqueTags: number = 0;
  
  // Community stats
  mostActiveAuthor: string = '';
  mostActiveAuthorPostCount: number = 0;
  mostActiveCommenter: string = '';
  mostActiveCommenterCount: number = 0;
  uniqueAuthors: number = 0;
  uniqueCommenters: number = 0;
  
  // Additional metrics
  postsWithNoLikes: number = 0;
  postsWithNoComments: number = 0;
  
  // Featured posts
  mostViewedPost: Post = {} as Post;
  mostCommentedPost: Post = {} as Post;
  mostCommentedPostCount: number = 0;
  mostLikedPost: Post = {} as Post;
  
  // Timeline posts
  oldestPost: Post = {} as Post;
  newestPost: Post = {} as Post;
  
  // Loading state
  isLoading: boolean = true;
  
  constructor(
    private http: HttpClient,
    private snackBar: MatSnackBar
  ) {}
  
  ngOnInit(): void {
    this.fetchBlogStatistics();
  }
  
  fetchBlogStatistics(): void {
    this.isLoading = true;
    
    this.http.get<Stats>(`http://localhost:8080/api/stats`).subscribe({
      next: (data : any) => {
        // Assign all stats from the response
        this.totalPosts = data.totalPosts;
        this.totalComments = data.totalComments;
        this.totalViews = data.totalViews;
        this.totalLikes = data.totalLikes;
        
        this.avgPostLength = data.avgPostLength;
        this.avgLikesPerPost = data.avgLikesPerPost;
        this.avgCommentsPerPost = data.avgCommentsPerPost;
        this.avgViewsPerPost = data.avgViewsPerPost;
        this.avgCommentLength = data.avgCommentLength;
        
        this.mostPopularTag = data.mostPopularTag;
        this.mostPopularTagCount = data.mostPopularTagCount;
        this.totalUniqueTags = data.totalUniqueTags;
        
        this.mostActiveAuthor = data.mostActiveAuthor;
        this.mostActiveAuthorPostCount = data.mostActiveAuthorPostCount;
        this.mostActiveCommenter = data.mostActiveCommenter;
        this.mostActiveCommenterCount = data.mostActiveCommenterCount;
        this.uniqueAuthors = data.uniqueAuthors;
        this.uniqueCommenters = data.uniqueCommenters;
        
        this.postsWithNoLikes = data.postsWithNoLikes;
        this.postsWithNoComments = data.postsWithNoComments;
        
        this.mostViewedPost = data.mostViewedPost;
        this.mostCommentedPost = data.mostCommentedPost;
        this.mostCommentedPostCount = data.mostCommentedPostCount;
        this.mostLikedPost = data.mostLikedPost;
        
        this.oldestPost = data.oldestPost;
        this.newestPost = data.newestPost;
        
        this.isLoading = false;
        console.log('Statistics loaded successfully');
      },
      error: (error : any) => {
        this.isLoading = false;
        console.error('Error fetching blog statistics:', error);
        this.snackBar.open('Failed to load blog statistics. Please try again later.', 'Close', {
          duration: 5000,
          panelClass: ['error-snackbar']
        });
        
        // Set fallback data for development/testing
        this.setFallbackData();
      }
    });
  }
  
  /**
   * Sets fallback data in case the API call fails
   * This is useful during development or when the backend is unavailable
   */
  private setFallbackData(): void {
    // Basic fallback data
    this.totalPosts = 0;
    this.totalComments = 0;
    this.totalViews = 0;
    this.totalLikes = 0;
    
    // Create empty post objects for featured posts
    this.mostViewedPost = {
      id: 0,
      name: 'No data available',
      content: 'Statistics could not be loaded. Please try again later.',
      postedBy: 'System',
      date: new Date(),
      imgUrl: 'assets/placeholder.jpg',
      tags: [],
      likeCount: 0,
      viewCount: 0
    } as Post;
    
    // Clone the fallback post for other featured posts
    this.mostCommentedPost = {...this.mostViewedPost};
    this.mostLikedPost = {...this.mostViewedPost};
    this.oldestPost = {...this.mostViewedPost};
    this.newestPost = {...this.mostViewedPost};
  }
}
