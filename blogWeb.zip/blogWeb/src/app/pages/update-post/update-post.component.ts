import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { AngularMaterialModule } from '../../AngularMaterialModule';
import { PostService } from '../../service/post.service';
import { CommonModule, Location } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-update-post',
  imports: [AngularMaterialModule, HttpClientModule, CommonModule, RouterModule],
  templateUrl: './update-post.component.html',
  styleUrl: './update-post.component.scss',
  providers: [PostService]
})
export class UpdatePostComponent {

  postForm !: FormGroup;
  tags: string[] = [];
  postId: any;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private snackBar: MatSnackBar,
    private location: Location,
    private activatedRoute: ActivatedRoute,
    private postService: PostService
  ) {

  }

  ngOnInit() {
    this.postId = this.activatedRoute.snapshot.params['id'];


    this.postForm = this.fb.group({
      name: [null, Validators.required],
      content: [null, [Validators.required, Validators.maxLength(50000)]],
      imgUrl: [null, Validators.required],
      postedBy: [{value: '', disabled: true}]
    })

    if (this.postId) {
      this.postService.getPostById(this.postId).subscribe({
        next: (post) => {
          // Populate the form with existing data
          this.postForm.patchValue({
            name: post.name,
            imgUrl: post.imgUrl,
            content: post.content,
            postedBy: post.postedBy
          });

          // Set the tags array
          this.tags = post.tags || [];
        },
        error: (error) => {
          console.error('Error fetching post:', error);
          this.snackBar.open("Something Went Wrong!!!", "OK", { duration: 4000 });
          // Handle error (show message, navigate away, etc.)
        }
      });
    }

  }

  updatePost() {
    const data = this.postForm.value;
    data.tags = this.tags;

    this.postService.updatePost(this.postId, data).subscribe(
      res => {
        this.snackBar.open("Post Updated Successfully!", "OK", { duration: 7000 });
        this.router.navigateByUrl("/");

      }, error => {
        console.log("error in post compon updatePost method", error);
        this.snackBar.open("Something Went Wrong!!!", "OK", { duration: 4000 });
      }
    )

  }

  addTag(event: any) {
    const tag = (event.value || '').trim();
    if (tag) {
      this.tags.push(tag);
    }
    event.chipInput!.clear();
  }

  removeTag(tag: any) {
    const index = this.tags.indexOf(tag);

    if (index >= 0) this.tags.splice(index, 1);
  }

  goBack(event: Event) {
    event.preventDefault();
    this.location.back();
  }

}
