import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { AngularMaterialModule } from '../../AngularMaterialModule';
import { PostService } from '../../service/post.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { CommentService } from '../../service/comment.service';
import { MatFormField } from '@angular/material/input';

@Component({
  selector: 'app-search-by-name',
  imports: [AngularMaterialModule, HttpClientModule, CommonModule, RouterModule],
  templateUrl: './search-by-name.component.html',
  styleUrl: './search-by-name.component.scss',
  providers: [PostService]
})

export class SearchByNameComponent {
  result: any = [];
  name: any = "";

  constructor(private postService: PostService, private snackBar: MatSnackBar) { }

  searchByName() {
    this.postService.searchPostByName(this.name).subscribe(res => {
      this.result = res;
      console.log(res);

    }, error => {
      console.log(error);
      this.snackBar.open("Something went wrong!!!", "OK", { duration: 4000 });
    });
  }
}
