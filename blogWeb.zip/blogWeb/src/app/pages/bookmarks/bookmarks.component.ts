import { Component } from '@angular/core';
import { BookmarkService } from '../../service/bookmark.service';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AngularMaterialModule } from '../../AngularMaterialModule';
import { PostService } from '../../service/post.service';

@Component({
  selector: 'app-bookmarks',
  standalone: true,
  imports: [AngularMaterialModule, CommonModule, HttpClientModule, CommonModule],
  templateUrl: './bookmarks.component.html',
  styleUrl: './bookmarks.component.scss',
  providers: [PostService]
})
export class BookmarksComponent {

  bookmarkedPosts: any[] = [];

  constructor(
    private bookmarkService: BookmarkService,
    private snackBar: MatSnackBar
  ) { }

  ngOnInit() {
    this.getBookmarkedPosts();
  }

  getBookmarkedPosts() {
    this.bookmarkService.getBookmarkedPosts().then((posts) => {
      console.log(posts);
      this.bookmarkedPosts = posts || [];

    }, error => {
      console.log(error);
      this.bookmarkedPosts = [];
      this.snackBar.open("Something went wrong!!!", "OK");
    });

  }

  resetAllBookmarks(): void {
    this.bookmarkService.resetBookmarks();
    this.bookmarkedPosts = [];
    this.snackBar.open("All bookmarks have been reset", "OK", { duration: 3000 });
  }



}
